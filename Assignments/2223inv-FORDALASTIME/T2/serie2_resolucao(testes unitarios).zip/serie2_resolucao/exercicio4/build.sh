
gcc -g -Wall -Og find_test.c multiple.s find.c ../invoke/invoke.s -o find_test
