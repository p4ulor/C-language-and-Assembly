
gcc -g -Wall rotate_right_test.c rotate_right.c ../invoke/invoke.s -o rotate_right_test
