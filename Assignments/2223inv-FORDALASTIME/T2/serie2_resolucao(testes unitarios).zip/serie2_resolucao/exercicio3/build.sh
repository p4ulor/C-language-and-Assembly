
gcc -g -Wall compare_data_value_test_a.c compare_data_value_a.c ../invoke/invoke.s -o compare_data_value_test_a

gcc -g -Wall compare_data_value_test_b.c compare_data_value_b.c ../invoke/invoke.s -o compare_data_value_test_b
