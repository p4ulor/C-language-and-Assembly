
gcc -g -Wall my_strlen_test.c my_strlen_asm.s ../invoke/invoke.s -o my_strlen_test
