#include <string.h>

size_t my_strlen(const char *string) {
	return strlen(string);
}
