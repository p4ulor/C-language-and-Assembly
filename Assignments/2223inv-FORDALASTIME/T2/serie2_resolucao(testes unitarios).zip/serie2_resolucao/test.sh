
echo ".............Teste do exercício 1"
cd exercicio1
./build.sh
./rotate_right_test

echo ".............Teste do exercício 2"
cd ../exercicio2
./build.sh
./my_strlen_test

echo ".............Teste do exercício 3"
cd ../exercicio3
./build.sh
./compare_data_value_test_a
./compare_data_value_test_b

echo ".............Teste do exercício 4"
cd ../exercicio4
./build.sh
./find_test
