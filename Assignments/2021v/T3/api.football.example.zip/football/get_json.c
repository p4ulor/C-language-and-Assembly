#include <string.h>
#include <stdio.h>
#include <errno.h>
#include <jansson.h>

int main(int argc, char *argv[1]) {
	int result = -1;

	if (argc != 2) {
		fprintf(stderr, "usage: %s <json_file>\n", argv[0]);
		return -1;
	}

	json_error_t error;
	json_t *root = json_load_file(argv[1], 0, &error);
	if (root == NULL) {
		fprintf(stderr, "***error: on line %d: %s\n", error.line, error.text);
		goto cleanup_1;
	}
	json_t *count = json_object_get(root, "count");
	if ( ! json_is_number(count)) {
		fprintf(stderr, "***error: \"count\" is not a number\n");
		goto cleanup_2;
	}

	printf("count = %lld\n", json_integer_value(count));
	result = 0;
cleanup_2:
	json_decref(root);
cleanup_1:
	return result;
}
