#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <curl/curl.h>


static size_t my_write(char *ptr, size_t size, size_t nmemb, void *fd) {
	return fwrite(ptr, size, nmemb, (FILE *)fd);
}

int get_url(const char *url, FILE *fd) {

	curl_global_init(CURL_GLOBAL_DEFAULT);

	CURL *curl = curl_easy_init();
	if (curl != NULL) {

		struct curl_slist *list = NULL;
		list = curl_slist_append(list, "X-Auth-Token: d43d8d80d7a54d1cb5421772a8f28aaf");
		curl_easy_setopt(curl, CURLOPT_HTTPHEADER, list);


		curl_easy_setopt(curl, CURLOPT_URL, url);

		curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, my_write);

		curl_easy_setopt(curl, CURLOPT_WRITEDATA, fd);

		curl_easy_setopt(curl, CURLOPT_VERBOSE, 3L);

		CURLcode res = curl_easy_perform(curl);

		curl_easy_cleanup(curl);
		if (CURLE_OK != res) {
			fprintf(stderr, "curl told us %d\n", res);
		}
	}
	curl_global_cleanup();
	return 1;
}

int main(int argc, char *argv[]) {
	if (argc != 3) {
		fprintf(stderr, "usage: %s <url> <file>\n", argv[0]);
		return 1;
	}
	FILE *fd = fopen(argv[2], "w");
	if (fd == NULL) {
		fprintf(stderr, "fopen: %s\n", strerror(errno));
		return 1;
	}
	if (get_url(argv[1], fd) == 0) {
		fprintf(stderr, "Erro\n");
		return 1;
	}
	fclose(fd);
}
